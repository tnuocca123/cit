﻿using System;
using System.Collections.Generic;
using System.IO;

namespace CApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = Directory.GetCurrentDirectory();
            Console.WriteLine(path);
            var tmp = File.ReadLines(path + "/check.txt");
            
            List<string> list = new List<string>();
            
            foreach (var line in tmp)
            {
                // Console.WriteLine(line);
                list.Add(line);
            }
            
            
            AplusPowB(list);
            
        }

        static void AplusPowB(List<string> list)
        {

            List<int> resultList = new List<int>();

            foreach (var s in list)
            {
                
                // string[] line = s.Split(' ');
                
                int[] nums = Array.ConvertAll(s.Split(' '), m => int.Parse(m));
                resultList.Add((int) (nums[0] + Math.Pow(nums[1], 2)));

            }
            
            Console.WriteLine(string.Join(" " , resultList));
            string path = Directory.GetCurrentDirectory();
            using (StreamWriter writer = new StreamWriter(path + "/output2.txt"))
            {

                foreach (var res in resultList)
                {
                    writer.WriteLine(res);
                    
                }
                writer.Close();
                
            }


        }
    }
}