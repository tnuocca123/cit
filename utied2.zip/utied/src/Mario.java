import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringJoiner;

public class Mario {

    public static void main(String[] args) {
        int inPt = Integer.parseInt(args[0]);
        StringJoiner result = new StringJoiner("\n");
        String def = "#";

        for (int i = 1; i <= inPt; i++) {
            result.add(String.format("%" + inPt + "s", def.repeat(i)));
        }

        System.out.println(result);

        kompare(result.toString());

    }


    private static void kompare(String com) {

        File file = new File("8.txt");
        String result = "";
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                result += scanner.nextLine()+"\n";

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        result = result.replaceAll("\n$", "");
        System.out.println(result);
        if (com.equals(result)) {
            System.out.println("Dame right");
        }
    }
}
