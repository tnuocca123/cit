public class Mario {
}
